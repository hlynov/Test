#ifndef HL_D3D_H
#define HL_D3D_H

#include <gtk/gtk.h>


int x;


typedef struct
{
    GtkLabel *lblresult;
    int x, y;
} mystruct;


// custom structure that will hold pointers to widgets and / or user variables
typedef struct {
    GtkWidget *w_lbl_time;
    GtkWidget *w_lbl_count;
} app_widgets;











#endif //  HL_D3D_H



