void mainwindowdraw()
{
};
