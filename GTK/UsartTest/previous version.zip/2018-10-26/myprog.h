#ifndef MYPROG_h__
#define MYPROG_h__

#include "main.h"



static void my_func(GtkButton*, GtkWindow*);
static void my_func2();
static void button_callback(GtkWidget* w ,gpointer data);
static void window_destroy();


void mainwindowdraw();


#endif










