#ifndef COMPORT_h__
#define COMPORT_h__

#include "main.h"



int set_interface_attribs(int fd, int speed);
void set_mincount(int fd, int mcount);
int comportInit(void);


#endif










