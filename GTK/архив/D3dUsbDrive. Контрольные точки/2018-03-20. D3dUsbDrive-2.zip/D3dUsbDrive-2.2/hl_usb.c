/* hl_usb.c
 *
 *
 *
 */


#include <gtk/gtk.h>
#include "hl_usb.h"

int res       = 0;  /* return codes from libusb functions */
int numBytes  = 0;  /* Actual bytes transferred. */
int rc;
int transferred = 0;
unsigned char Report_to_read[64];

unsigned char buf[DATA_SIZE];
int act_len = 0;

libusb_device_handle *dev_handle = NULL;   //a device handle
libusb_context       *ctx = NULL;           //a libusb session
libusb_device        *dev = NULL;          //pointer to device
libusb_device        **devs = NULL;        //pointer to pointer of device



void myTestFunc()
{
    g_print("my TestFunction is work!!! \n");

};



void concheck( libusb_device_handle *handle, GtkWidget *lblConnectionStatus)
{
    //Check connection status
    if (handle == NULL) {
        gtk_label_set_text(GTK_LABEL(lblConnectionStatus), "Device not connected.");
        g_print ("Device No Connected \n");
    }
    else
    {
        gtk_label_set_text(GTK_LABEL(lblConnectionStatus), "OK! Device connected!");
        g_print ("Device Connected \n");
    }
}


//End Check connection status











